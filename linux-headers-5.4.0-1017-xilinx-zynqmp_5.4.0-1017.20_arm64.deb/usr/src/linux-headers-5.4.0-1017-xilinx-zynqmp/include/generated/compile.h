/* This file is auto generated, version 20 */
/* SMP */
#define UTS_MACHINE "aarch64"
#define UTS_VERSION "#20 SMP Thu Nov 10 16:16:12 CET 2022"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "kernighan"
#define LINUX_COMPILER "gcc version 7.5.0 (Ubuntu/Linaro 7.5.0-3ubuntu1~18.04)"
