#define UTS_RELEASE "5.4.0-1017-xilinx-zynqmp"
#define UTS_UBUNTU_RELEASE_ABI 1017
